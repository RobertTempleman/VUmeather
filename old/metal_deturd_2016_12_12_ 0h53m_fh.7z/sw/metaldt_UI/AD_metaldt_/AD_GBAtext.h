// scrollher2View.h : interface of the Cscrollher2View class
//
#pragma once
void print_pretty_byte(u8 screen_x,u8 screen_y,const char *string, COLORREF colour_alpha, COLORREF colour_number, COLORREF colour_operators,bool auto_kern=false,bool no_output=false,bool no_space=false,bool masked=false);
